package usagelist;
import java.util.*;
import java.util.Set;

public class SetExample {

    // Methods
	//to create and print a HashSet
    public static void printHashSet() {
        Set<String> set = new HashSet<>();
        set.add("Shawkim");
        set.add("STC");
        set.add("Malta");
        set.add("Wlv");
        set.add("Canvas");
        System.out.println("HashSet: " + set);
    }

    // Methods
    //to create a TreeSet and print it
    public static void printTreeSet() {
        Set<String> set = new HashSet<>();
        set.add("Shawkim");
        set.add("STC");
        set.add("Malta");
        set.add("Wlv");
        set.add("Canvas");
        Set<String> sortedSet = new TreeSet<>(set);
        System.out.println("TreeSet: " + sortedSet);
        
    }
    public static void main(String args[]) {
        // print HashSet
        printHashSet();

        // print TreeSet
        printTreeSet();
    }
    /*
     * printHashSet & printTreeSet It will take care of the set's creation and display functionality. To build and show the sets, the main function now calls these two methods. 
     
    HashSet is used to store a collection of distinct items; it forbids duplicates and does not ensure the order. 
    TreeSet is a data structure that only accepts unique objects and is used to store collections of items in sorted order.
    */
    

}
