package listusage;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListExample {
  public static void main(String args[]) {
    ListExample example = new ListExample();
    example.listExample();
  }
  
  public void listExample(){
    //Creating an ArrayList and adding elements
    List<String> arrayList = new ArrayList<>();
    arrayList.add("Shawkim");
    arrayList.add("STC");
    arrayList.add("Malta");
    arrayList.add("Wlv");
    arrayList.add("Canvas");
    System.out.println("ArrayLst: " + arrayList);
    System.out.println("ArrayLst second element: " + arrayList.get(2));
    System.out.println("ArrayList first element: " + arrayList.get(0));
    
    //Creating a LinkedList and adding elements
    LinkedList<String> linkedList = new LinkedList<>();
    linkedList.addFirst("Shawkim");
    linkedList.addFirst("STC");
    linkedList.addFirst("Malta");
    linkedList.addFirst("Wlv");
    linkedList.addFirst("Canvas");
    System.out.println("LinkedList: " + linkedList);
    linkedList.removeLast();
    linkedList.removeLast();
    System.out.println("LinkedList after removing last two elements: " + linkedList);
  }
}
