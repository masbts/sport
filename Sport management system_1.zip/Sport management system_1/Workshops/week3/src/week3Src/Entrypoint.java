package week3Src;

public class Entrypoint {

	public static void main(String[] args) {
	    Name name = new Name("Alan", "Mathson", "Turing");
	    Car car = new Car("Honda", "Civic", 30, 15);
	    car.setOwner(name);
	    System.out.println(car.tankBigger(20));
	}
	}

