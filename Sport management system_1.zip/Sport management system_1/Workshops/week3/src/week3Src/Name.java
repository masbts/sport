package week3Src;

public class Name {

	//Attributes
	private String firstname;
	private String middlename;
	private String surname;
    private Car[] cars;
    private static final int MAX_CARS = 5;
    
    // constructor that takes a fullname string
    public Name(String fullname) {
        // split the fullname string and assign to fname, mname, and sname
        String[] parts = fullname.split(" ");
        this.firstname = parts[0];
        this.middlename = parts[1];
        this.surname = parts[2];
        this.cars = new Car[MAX_CARS];
    }

	
	//Getters
	public String getFirstname() {
		return firstname;
	}
	
	public String getMiddlename() {
		return middlename;
	}

	public String getSurname() {
		return surname;
	}

	
	// Setters
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	//Constructors
	public Name() {
		//empty constructor
	}
	
	public Name(String fname, String mname, String sname) {
	//Overloaded Constructor
		this.firstname = fname;
		this.middlename = mname;
		this.surname = sname;
	}
	
	
	
	//Methods
	/*
	 * public String getDetails() {
	 
		String details = "Firstname : "+getFirstname()+"\n"
		+ "Middle name and Surname : "+getMiddlename()+" "+getSurname();
		
		return details;
	}
	*/
	   public String getLasscommafirst() {
	        return surname + ", " + firstname;
	    }
	    
	    // method to return full name
	    public String getFullName() {
	        return firstname + " " + middlename + " " + surname;
	    }
	    
	    // method to return first and last name
	    public String getFirstAndLastName() {
	        return firstname + " " + surname;
	    }

	    public void addCar(Car car) {
	        for(int i = 0; i < cars.length; i++) {
	            if(cars[i] == null) {
	                cars[i] = car;
	                car.setOwner(this);
	                break;
	            }
	        }
	    }
	    
	    public Car[] getCars() {
	        return cars;
	    }
	    
	    public void setCars(Car[] cars) {
	        this.cars = cars;
	    }
	

		public Car getThirdCar() {
			// TODO Auto-generated method stub
			return null;
		}
	
}
