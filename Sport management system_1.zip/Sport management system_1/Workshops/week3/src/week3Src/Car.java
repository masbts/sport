package week3Src;

public class Car {

	
		// TODO Auto-generated method stub
		
		    private String make;
		    private String model;
		    private int manfMPG;
		    private double tankSize;
		    private Name owner;
		    
		    // constructor that takes make, model, manfMPG, and tankSize
		    public Car(String make, String model, int manfMPG, double tankSize) {
		        this.setMake(make);
		        this.setModel(model);
		        this.setManfMPG(manfMPG);
		        this.setTankSize(tankSize);
		    }

			/**
			 * @return the make
			 */
			public String getMake() {
				return make;
			}

			/**
			 * @param make the make to set
			 */
			public void setMake(String make) {
				this.make = make;
			}

			/**
			 * @return the manfMPG
			 */
			public int getManfMPG() {
				return manfMPG;
			}

			/**
			 * @param manfMPG the manfMPG to set
			 */
			public void setManfMPG(int manfMPG) {
				this.manfMPG = manfMPG;
			}

			/**
			 * @return the model
			 */
			public String getModel() {
				return model;
			}

			/**
			 * @param model the model to set
			 */
			public void setModel(String model) {
				this.model = model;
			}

			/**
			 * @return the tankSize
			 */
			public double getTankSize() {
				return tankSize;
			}

			/**
			 * @param tankSize the tankSize to set
			 */
			public void setTankSize(double tankSize) {
				this.tankSize = tankSize;
			}

			/**
			 * @return the owner
			 */
			public Name getOwner() {
				return owner;
			}

			/**
			 * @param owner the owner to set
			 */
			public void setOwner(Name owner) {
				this.owner = owner;
			}
			
		
			
			//Methods
			
			public String tankBigger(double size) {
				
		        if (this.tankSize > size) 
		       {
		            return "inefficient fuel use";
		        } 
		        else if (this.tankSize < size) {
		            return "good fuel consumption";
		        }
		        else {
		            return "average consumer";
		        }
		    }
			public double estimatedDistance(double GPL) {
		        return tankSize * manfMPG * GPL;
		    }

}
