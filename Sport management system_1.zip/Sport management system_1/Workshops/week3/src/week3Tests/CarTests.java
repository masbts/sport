package week3Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import week3Src.Car;

class CarTests {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void testCar() {
	}

	@Test
	void testGetMake() {
	}

	@Test
	void testSetMake() {
	}

	@Test
	void testGetManfMPG() {
	}

	@Test
	void testSetManfMPG() {
	}

	@Test
	void testGetModel() {
	}

	@Test
	void testSetModel() {
	}

	@Test
	void testGetTankSize() {
	}

	@Test
	void testSetTankSize() {
	}

	@Test
	void testGetOwner() {
	}

	@Test
	void testSetOwner() {

	}

	@Test
	void testTankBigger() {
		  Car car = new Car("Honda", "Civic", 30, 15);
	        String expected = "good fuel consumption";
	        String actual = car.tankBigger(20);
	        assertEquals(expected, actual);	}

	@Test
	 void testEstimatedDistance() {
        Car car = new Car("Honda", "Civic", 30, 15);
        double expectedDistance = 279.0;
        double actualDistance = car.estimatedDistance(0.62);
        assertEquals(expectedDistance, actualDistance, 0.1);
    }

}
