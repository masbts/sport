package week3Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import week3Src.Car;
import week3Src.Name;

class NameTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void testGetLasscommafirst() {
		    Name name = new Name("Alan", "Mathson", "Turing");
	        String expected = "Alan, Mathson";
	        String actual = name.getLasscommafirst();
	        assertEquals(expected, actual);
	    }
	public void testGetThirdCar() {
        Name name = new Name("Alan", "Mathson", "Turing");
        Car car1 = new Car("Honda", "Civic", 30, 15);
        Car car2 = new Car("Toyota", "Corolla", 25, 20);
        Car car3 = new Car("Ford", "Fiesta", 35, 10);
        Car car4 = new Car("BMW", "X5", 20, 25);
        Car car5 = new Car("Mercedes", "Benz", 30, 15);
        name.addCar(car1);
        name.addCar(car2);
        name.addCar(car3);
        name.addCar(car4);
        name.addCar(car5);
        Car expected = car3;
        Car actual = name.getThirdCar();
        assertEquals(expected, actual);
    }

}
