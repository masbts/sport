package week6;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class StudentList {
private ArrayList<Student> studentList;
//create an empty arraylist

    public StudentList() {
        studentList = new ArrayList<Student>();
    }
	
	//add a student s to the collection

    public void add(Student s) {
        studentList.add(s);
    }
	
    
	//returns a report with one line per person
	// traverses the array list,
	//getting one element at a time

    public String getAllStudents() {
        String report = "";
        for (Student student : studentList) {
            report += student.toString() + "\n";
        }
        return report;
    }
	
	//returns the number of elements in the list

    public int getSize() {
        return studentList.size();
    }
	//returns the Student object at specified index position

    public Student getAtIndex(int index) {
        return studentList.get(index);
    }
	//returns the Student object with a specified id
	// searches through the array
	//and stopping by returning when a match is found

    public Student findById(String id) {
        for (Student student : studentList) {
            if (student.getId().equals(id)) {
                return student;
            }
        }
   	    return null;
    }
    //counts the number of people in a specified year
    //demonstrates making a count with arraylists

    public int getCountOfPeopleAtYear(int year) {
        int count = 0;
        for (Student student : studentList) {
            if (student.getYear() == year) {
                count++;
            }
        }
        return count;
    }
	//works out how many people in each year,
	//then creates and returns a report
    //
    //demonstrates calculating a frequency report
    //i.e. how often each year occurs
    //it uses the value of the year as an index

    public String getYearsFrequencyReport() {
        int maxYear = getMaxYear();
        int[] years = new int[maxYear + 1];
        for (Student student : studentList) {
            years[student.getYear()]++;
        }
        String report = "Year, Frequency\n";
        for (int i = 0; i < years.length; i++) {
            if (years[i] > 0) {
                report += i + ", " + years[i] + "\n";
            }
        }
        return report;
    }
	
	//calculates the maximum year that anyone is in
	//demonstrates finding a max with array lists

    public int getMaxYear() {
        int maxYear = Integer.MIN_VALUE;
        for (Student student : studentList) {
            maxYear = Math.max(maxYear, student.getYear());
        }
        return maxYear;
    }
    /* writes supplied text to file
	 * @param filename the name of the file to be written to
	 * @param report the text to be written to the file
	 */

    public void writeToFile(String filename, String report) {
        try {
            FileWriter fw = new FileWriter(filename);
            fw.write(report);
            fw.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        } catch (IOException e) {
            System.out.println("Error: IO exception.");
        }
    }
	
    
	/** reads file with given name, extracting student data, creating student objects
	 * and adding them to the list of students
	 * Blank lines are skipped
	 * Validation for integer year, missing items
	 * @param filename the name of the input file
	 */
    public void readFile(String filename) {
        try {
            Scanner scanner = new Scanner(new File(filename));
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.trim().length() > 0) {
                    processLine(line);
                }
            }
            scanner.close();
    		//for these two formatting errors, ignore lines in error   and try and carry on
    		
    		//this catches trying to convert a String to an integer

        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        }
    }
	
	/**
	 * Processes line, extracts data, creates Student object
	 * and adds to list
	 * Checks for non-numeric year and missing items
	 * Will still crash if name entered without a space
	 * @param line - the line to be processed
	 */

    private void processLine(String line) {
        String[] parts = line.split(",");
        if (parts.length < 4) {
            System.out.println("Error: Invalid data format in line: " + line);
            return;
        }
        Name name = new Name(parts[1]);
        String id = parts[0];
        String yearNum = parts[2];
        yearNum = yearNum.trim();
        int year;
        try {
            year = Integer.parseInt(yearNum);
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid year format in line: " + line);
            return;
        }
        int qualLength = parts.length - 3;
        String[] quals = new String[qualLength];
        System.arraycopy(parts, 3, quals, 0, qualLength);
        Student student = new Student(id, name, year, quals);
        studentList.add(student);
    	}
    
   
        }

