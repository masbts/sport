package week1;
//revision

public class BankAccount {
    private int accountNumber;
    private String accountName;
    private double balance;
    private static final double MIN_BALANCE = 0;

    // Default constructor
    public BankAccount() {
        this.balance = MIN_BALANCE;
        this.accountName = "";
    }

    // Parameterized constructor
    public BankAccount(int accountNumber, String accountName, double balance) {
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.balance = balance;
    }

    // Method to deposit money
    public void deposit(double amount) {
        this.balance += amount;
    }

    // Method to withdraw money
    public boolean withdraw(double amount) {
        if (this.balance - amount < MIN_BALANCE) {
            System.out.println("Insufficient balance!");
            return false;
        }
        this.balance -= amount;
        return true;
    }

    // Method to check current balance
    public double checkBalance() {
        return this.balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }
}