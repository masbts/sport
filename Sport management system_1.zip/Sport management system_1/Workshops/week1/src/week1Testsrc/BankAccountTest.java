package week1Testsrc;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import week1.BankAccount;

class BankAccountTest {
	// Test default constructor
	    @Test
	    public void testDefaultConstructor() {
	        BankAccount account = new BankAccount();
	        assertEquals(0, account.checkBalance(), 0);
	        assertEquals("", account.getAccountName());
	    }

	    // Test parameterized constructor
	    @Test
	    public void testParameterizedConstructor() {
	        BankAccount account = new BankAccount(12345, "Shawkim Doe", 100);
	        assertEquals(12345, account.getAccountNumber());
	        assertEquals("Shawkim Doe", account.getAccountName());
	        assertEquals(100, account.checkBalance(), 0);
	    }

	    // Test deposit method
	    @Test
	    public void testDeposit() {
	        BankAccount account = new BankAccount();
	        account.deposit(100);
	        assertEquals(100, account.checkBalance(), 0);
	    }

	    // Test withdraw method
	    @Test
	    public void testWithdraw() {
	        BankAccount account = new BankAccount();
	        account.deposit(100);
	        assertTrue(account.withdraw(50));
	        assertEquals(50, account.checkBalance(), 0);
	        assertFalse(account.withdraw(100));
	    }

	    // Test check balance method
	    @Test
	    public void testCheckBalance() {
	        BankAccount account = new BankAccount();
	        account.deposit(100);
	        assertEquals(100, account.checkBalance(), 0);
	    }
	   


}
