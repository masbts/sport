package week1Testsrc;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import week1.Car;

class CarTest {

	@Test
	void testCar() {
		  Car car = new Car("Model", 20, 30.0);
	        assertEquals("Model", car.getModel());
	        assertEquals(20, car.getTankSize());
	}

	@Test
	void testSetModel() {
	}

	@Test
	void testGetModel() {
	}

	@Test
	void testSetTankSize() {
		Car car = new Car("Model", 20, 30.0);
	        car.setModel("New Model");
	        car.setTankSize(25);
	        assertEquals("New Model", car.getModel());
	        assertEquals(25, car.getTankSize());	}

	@Test
	void testGetTankSize() {
	}

	@Test
	void testEstimateDistance() {
	      Car car = new Car("Model", 20, 30.0);
	        assertEquals(132.0, car.estimateDistance(),0.001); //198.4 error
	        //  delta value which is used to check the equality of floating-point values if used 198.4 will result an error
	}

}
